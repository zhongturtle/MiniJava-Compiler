# MiniJava-Compiler

## compile
 -  ./script

## parser
 -  cd folder
 -  java MiniJava ../Fatorial.java
